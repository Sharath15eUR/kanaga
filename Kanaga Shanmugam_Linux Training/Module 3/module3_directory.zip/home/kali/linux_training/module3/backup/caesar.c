#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

int main()
{
    char message[500], c;
    int i;
    int key;

    printf("Enter a message to encrypt: ");
    scanf("%[^\n]", message); // Read the whole line including spaces

    printf("Enter key: ");
    scanf("%d", &key);

    for (i = 0; message[i] != '\0'; i++) {
        c = message[i];

        // Encrypt alphabets (both lowercase and uppercase)
        if (isalpha(c)) {
            if (islower(c)) {
                c = (c - 'a' + key) % 26 + 'a';
            } else {
                c = (c - 'A' + key) % 26 + 'A';
            }
        } else { // Encrypt special characters
            c = (c + key) % 128;
        }

        message[i] = c;
    }

    printf("Encrypted message: %s\n", message);
    
    printf("*****Decryption*****");
    //char message[500], c;
    //int i;
    //int key;

    printf("Enter a message to decrypt: ");
    scanf("%[^\n]", message); // Read the whole line including spaces

    printf("Enter key: ");
    scanf("%d", &key);

    for (i = 0; message[i] != '\0'; i++) {
        c = message[i];

        // Decrypt alphabets (both lowercase and uppercase)
        if (isalpha(c)) {
            if (islower(c)) {
                c = (c - 'a' - key + 26) % 26 + 'a';
            } else {
                c = (c - 'A' - key + 26) % 26 + 'A';
            }
        } else { // Decrypt special characters
            c = (c - key + 128) % 128;
        }

        message[i] = c;
    }

    printf("Decrypted message: %s\n", message);

    return 0;
}

