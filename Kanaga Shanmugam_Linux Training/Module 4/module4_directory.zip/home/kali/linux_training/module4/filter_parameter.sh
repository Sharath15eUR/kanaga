#!/bin/bash

if [ ! -f "output.txt" ];then
	touch "output.txt"
fi

while read -r line; do
    keyword=$(echo $line  | awk -F ":" '{print $1}')

    if [[ $keyword == "\"frame.time\"" || $keyword == "\"wlan.fc.type\"" || $keyword == "\"wlan.fc.subtype\"" ]]; then
        echo "$line" >> "output.txt" 
    fi
done < "input.txt"

